
const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');

function sendMessage() {
    const message = userInput.value.trim();
    if(message) {
        chatBox.innerHTML += `<div><b>Tú:</b> ${message}</div>`;
        userInput.value = '';
        setTimeout(() => {
            chatBox.innerHTML += `<div><b>María:</b> Estoy procesando tu mensaje...</div>`;
            chatBox.scrollTop = chatBox.scrollHeight;
        }, 1000);
    }
}
